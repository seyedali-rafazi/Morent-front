export const germanCitys = [
  {
    id: 1,
    name: "Berlin",
    unavailable: false,
  },
  {
    id: 2,
    name: "Munich",
    unavailable: false,
  },
  {
    id: 3,
    name: "Hamburg",
    unavailable: false,
  },
  {
    id: 4,
    name: "Cologne",
    unavailable: false,
  },
  {
    id: 5,
    name: "Frankfurt",
    unavailable: false,
  },
  {
    id: 6,
    name: "Dresden",
    unavailable: false,
  },
];

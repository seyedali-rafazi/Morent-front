import { Box } from "@mui/material";
import Pickup from "./Pickup";

function OrderInformation() {
  return (
    <Box>
      <Pickup text={"Pick-Up"} />
    </Box>
  );
}

export default OrderInformation;
